const taskForm = document.getElementById("taskForm");
const tasksBox = document.getElementById("tasks");
const filter = document.getElementById("filter");

let tasks = JSON.parse(localStorage.getItem("myStudyTasks") || "[]");
let dailyGoal = Number(localStorage.getItem("studyGoal") || 3);

document.getElementById("dailyGoal").value = dailyGoal;

document.getElementById("today").textContent =
  new Date().toLocaleDateString("en-IN", {
    day: "numeric",
    month: "short",
    year: "numeric"
  });

document.getElementById("saveGoal").addEventListener("click", () => {
  const value = Number(document.getElementById("dailyGoal").value);
  if (value < 1) return;

  dailyGoal = value;
  localStorage.setItem("studyGoal", dailyGoal);
  updateDashboard();
});

taskForm.addEventListener("submit", function(event) {
  event.preventDefault();

  const task = {
    id: Date.now(),
    name: document.getElementById("taskName").value.trim(),
    subject: document.getElementById("subject").value.trim(),
    date: document.getElementById("date").value,
    priority: document.getElementById("priority").value,
    completed: false
  };

  tasks.push(task);
  saveTasks();
  taskForm.reset();
  document.getElementById("priority").value = "Medium";
  render();
});

function saveTasks() {
  localStorage.setItem("myStudyTasks", JSON.stringify(tasks));
}

function render() {
  renderTasks();
  renderSubjects();
  updateDashboard();
}

function renderTasks() {
  let visibleTasks = tasks;

  if (filter.value === "pending") {
    visibleTasks = tasks.filter(task => !task.completed);
  }

  if (filter.value === "done") {
    visibleTasks = tasks.filter(task => task.completed);
  }

  tasksBox.innerHTML = "";

  if (visibleTasks.length === 0) {
    tasksBox.innerHTML = '<p class="muted">No tasks here yet. Add your first study task.</p>';
    return;
  }

  visibleTasks.forEach(task => {
    const row = document.createElement("div");
    row.className = "task" + (task.completed ? " completed" : "");

    row.innerHTML = `
      <input class="check" type="checkbox" ${task.completed ? "checked" : ""}
        onchange="toggleTask(${task.id})">
      <div class="task-main">
        <div class="task-name">${safe(task.name)}</div>
        <div class="task-meta">${safe(task.subject)} • ${task.date}</div>
      </div>
      <span class="badge">${task.priority}</span>
      <button class="delete" onclick="removeTask(${task.id})">Delete</button>
    `;

    tasksBox.appendChild(row);
  });
}

function renderSubjects() {
  const subjects = {};

  tasks.forEach(task => {
    if (!subjects[task.subject]) {
      subjects[task.subject] = { total: 0, done: 0 };
    }

    subjects[task.subject].total++;

    if (task.completed) {
      subjects[task.subject].done++;
    }
  });

  const names = Object.keys(subjects);
  const area = document.getElementById("subjects");
  document.getElementById("subjectCount").textContent =
    names.length + (names.length === 1 ? " subject" : " subjects");

  if (!names.length) {
    area.innerHTML = '<p class="muted">Your subject progress will appear here.</p>';
    return;
  }

  area.innerHTML = names.map(name => {
    const item = subjects[name];
    const percent = Math.round((item.done / item.total) * 100);

    return `
      <div class="subject-item">
        <div class="subject-line">
          <span>${safe(name)}</span>
          <span>${percent}%</span>
        </div>
        <div class="bar">
          <div class="bar-fill" style="width:${percent}%"></div>
        </div>
      </div>
    `;
  }).join("");
}

function updateDashboard() {
  const total = tasks.length;
  const done = tasks.filter(task => task.completed).length;
  const left = total - done;
  const percent = total ? Math.round((done / total) * 100) : 0;

  document.getElementById("total").textContent = total;
  document.getElementById("done").textContent = done;
  document.getElementById("left").textContent = left;
  document.getElementById("percent").textContent = percent + "%";

  const todayDone = tasks.filter(task =>
    task.completed && task.date === new Date().toISOString().split("T")[0]
  ).length;

  document.getElementById("goalText").textContent =
    `Today's completed tasks: ${todayDone}/${dailyGoal}`;
}

function toggleTask(id) {
  const task = tasks.find(item => item.id === id);
  if (!task) return;

  task.completed = !task.completed;
  saveTasks();
  render();
}

function removeTask(id) {
  tasks = tasks.filter(item => item.id !== id);
  saveTasks();
  render();
}

function safe(value) {
  return value.replace(/[&<>"']/g, character => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#039;"
  }[character]));
}

filter.addEventListener("change", render);

render();
