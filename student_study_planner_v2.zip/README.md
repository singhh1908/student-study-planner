# Student Study Planner 📚

**Student Study Planner** is a small web project I built to organize my daily study tasks.

## What I built
- Add a study task with subject, date and priority
- Track completed and pending work
- Set a daily study goal
- See subject-wise progress
- Filter tasks
- Keep tasks saved in the browser

## Technologies
HTML, CSS and JavaScript

## How to run
1. Download/clone this repository.
2. Open `index.html` in a browser.
3. Add your subjects and study tasks.

## Why I made it
I wanted a simple planner that I could actually use for college studies while also practicing JavaScript and browser storage.
